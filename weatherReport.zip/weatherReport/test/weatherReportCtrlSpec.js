/*global describe, it, beforeEach, inject, expect*/
(function () {
	'use strict';

	describe('Todo Controller', function () {
		var ctrl, scope, store;

		// Load the module containing the app, only 'ng' is loaded by default.
		beforeEach(module('weatherReport'));

		beforeEach(inject(function ($controller, $rootScope, localStorage) {
			scope = $rootScope.$new();

			store = localStorage;

			ctrl = $controller('weatherReportCtrl', {
				$scope: scope,
				store: store
			});
		}));


		describe('having no Todos', function () {
			var ctrl,httpBackend;

			beforeEach(inject(function ($controller,$httpBackend) {
				ctrl = $controller('weatherReportCtrl', {
					$scope: scope,
					store: store
				});
                httpBackend = $httpBackend;
				scope.$digest();
			}));

			it('should not search for empty field', function () {
				scope.searchItem = '';
				scope.addTodo();
				scope.$digest();
				expect(scope.searchCity.length).toBe(0);
			});

			it('should not search only for whitespaces', function () {
				scope.searchItem = '   ';
				scope.addTodo();
				scope.$digest();
				expect(scope.searchCity.length).toBe(0);
			});


			it('should trim whitespace from new searched city', function () {
				scope.searchItem = '  delhi  ';
                httpBackend
                    .expect('GET', 'http://api.openweathermap.org/data/2.5/weather?q=delhi&appid=73bf55ce9bac20cfb5b02bca95595d6f')
                    .respond(200, { foo: 'bar' });
				scope.addTodo();
				scope.$digest();
				expect(scope.searchCity.length).toBe(5);
			});
		});

	});
}());
