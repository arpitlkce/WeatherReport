/*global angular */

/**
 * The main Weather Report app module
 *
 * @type {angular.Module}
 */

angular = require('angular');
require('angular-route');
require('../dist/templateCachePartials');

angular.module('weatherReport', ['ngRoute','todoPartials'])
	.config(function ($routeProvider) {
		'use strict';

		var routeConfig = {
			controller: 'weatherReportCtrl',
			templateUrl: '/partials/weatherReport.html',
			resolve: {
				store: ['weatherReportService', function (todoStorage) {
					// Get the correct module (API or localStorage).
					return todoStorage;
				}]
			}
		};

		$routeProvider
			.when('/', routeConfig)
			.otherwise({
				redirectTo: '/'
			});
	});

require('weatherReportController');
require('weatherReportService');
