/*global angular */

/**
 * Services that persists and retrieves todos from a backend API
 * if available.
 *
 * returning promises for all changes to the
 * model.
 */
angular = require('angular');

angular.module('weatherReport')
	.factory('weatherReportService', function ($http, $injector) {
		'use strict';
		return $injector.get('localStorage');
	})
	.factory('localStorage', function ($q,$http) {
		'use strict';

		var store = {
			get: function(city){
                var deferred = $q.defer();
                $http.get('http://api.openweathermap.org/data/2.5/weather?q='+city+'&appid=73bf55ce9bac20cfb5b02bca95595d6f')
                    .then(function(data) {
                        deferred.resolve(data);
                    },function(msg, code) {
                        deferred.reject(msg);
                    });
                return deferred.promise;
            }

		};

		return store;
	});
