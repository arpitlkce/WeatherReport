/*global angular */

/**
 * The main controller for the app. The controller:
 * - retrieves and persists the model via the todoStorage service
 * - exposes the model to the template and provides event handlers
 */
angular = require('angular');

angular.module('weatherReport')
	.controller('weatherReportCtrl', function TodoCtrl($scope, store) {
		'use strict';
		$scope.tableData = [];

		$scope.searchItem = '';

		$scope.addTodo = function (todo) {
            $scope.searchCity = $scope.searchItem.trim();
            if($scope.searchCity.length !==0) {
                store.get($scope.searchCity).then(
                    function(payload) {
                        $scope.createTableData(payload.data);
                    },
                    function(errorPayload) {
                        console.log('failure loading weather', errorPayload);
                    });
            }

		};

        $scope.createTableData = function (data) {
        	var Obj = {};
        	Obj.city = data.name;
            Obj.midNight = data.main.temp_min;
            Obj.morning = data.main.temp;
            Obj.afterNoon = data.main.temp_max;
            Obj.evening = data.main.temp;

            $scope.tableData.push(Obj);
            $scope.searchItem = '';

        }


	});
