describe('Check table for weather ', function() {
    it('should add a todo', function() {
        browser.get('http://localhost:8000/dist/index.html#!/');

        element(by.model('searchItem')).sendKeys('Delhi');
        element(by.css('[value="Search"]')).click();

        var todoList = element.all(by.repeater('row in tableData'));
        expect(todoList.count()).toEqual(5);
        expect(todoList.get(1).getText()).toEqual('delhi');
    });
});